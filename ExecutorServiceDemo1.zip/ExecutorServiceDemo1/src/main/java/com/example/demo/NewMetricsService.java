package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.Lists;

public class NewMetricsService {

	//@Autowired
	AsyncService service = new AsyncService();
	
	public List<CompletableFuture<String>> getCompletableFutureList(){
		List<String> queryList =  getQueryList();
		List<List<String>> lst = Lists.partition(queryList, 5);
		List<CompletableFuture<String>> futures = new ArrayList();
		for(List<String> partialquery : lst) {
			List<CompletableFuture<String>> partialFutures = new ArrayList();
			for(String str : partialquery) {
				partialFutures.add(service.getdata(str));
			}
			CompletableFuture.allOf(partialFutures.toArray(new CompletableFuture[partialFutures.size()])).join();
			futures.addAll(partialFutures);
		}
		return futures;
	}
	
	public List<String> getQueryList() {
		List<String> queryList = new ArrayList();
		queryList.add("query1");
		queryList.add("query2");
		queryList.add("query3");
		queryList.add("query4");
		queryList.add("query5");
		queryList.add("query6");
		queryList.add("query7");
		queryList.add("query8");
		queryList.add("query9");
		queryList.add("query10");
		queryList.add("query11");
		queryList.add("query12");
		queryList.add("query13");
		queryList.add("query14");
		queryList.add("query15");
		return queryList;
	}
}
