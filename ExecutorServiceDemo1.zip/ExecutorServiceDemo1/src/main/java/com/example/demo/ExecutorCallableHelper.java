package com.example.demo;

import java.util.concurrent.Callable;

public class ExecutorCallableHelper implements Callable<String> {    
    private String queryString;
    private repo rp = new repo();
    
    public ExecutorCallableHelper(String queryString) {
		super();
		this.queryString = queryString;
	}


	@Override    
    public String call() throws Exception {   
		System.out.println("in ExecutorCallableHelper");
        return rp.getdata(queryString);    
    }    
       
    
}   
