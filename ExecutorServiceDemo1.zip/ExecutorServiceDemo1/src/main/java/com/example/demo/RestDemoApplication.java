package com.example.demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
//@EnableJpaRepositories
//@EntityScan(basePackages = "com.app.model")
public class RestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestDemoApplication.class, args);

		MetricsService mtrservice = new MetricsService();
		//mtrservice.getCompletableFutureListWithNewApproach();
		/*List<CompletableFuture<String>> lst = mtrservice.getCompletableFutureList();
		
		try {
			for(CompletableFuture<String> ftr : lst) {
				System.out.println(ftr.get());
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	*/	
		
		
		
		ExecutorService executor = Executors.newFixedThreadPool(3);
		List<Future<String>> list = new ArrayList<Future<String>>();    
        Callable<String> callable1 = new ExecutorCallableHelper("1"); 
        Callable<String> callable2 = new ExecutorCallableHelper("2"); 
        Callable<String> callable3 = new ExecutorCallableHelper("3"); 
        Callable<String> callable4 = new ExecutorCallableHelper("4"); 
        Callable<String> callable5 = new ExecutorCallableHelper("5"); 

		/*
		 * executor.submit(callable1); executor.submit(callable2);
		 * executor.submit(callable3); executor.submit(callable4);
		 * executor.submit(callable5); executor.submit(callable1);
		 */

		CompletableFuture<Callable<String>> futureOutput = CompletableFuture.supplyAsync(() -> callable1, executor);
		CompletableFuture<Callable<String>> futureOutput1 = CompletableFuture.supplyAsync(() -> callable2, executor);
		CompletableFuture<Callable<String>> futureOutput2 = CompletableFuture.supplyAsync(() -> callable3, executor);
		CompletableFuture<Callable<String>> futureOutput3 = CompletableFuture.supplyAsync(() -> callable4, executor);
		CompletableFuture<Callable<String>> futureOutput4 = CompletableFuture.supplyAsync(() -> callable5, executor);

		  try {
			System.out.println(new Date()+ "::"+futureOutput.get());
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
	
}
