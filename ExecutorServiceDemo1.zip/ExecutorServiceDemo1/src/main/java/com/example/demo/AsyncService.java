package com.example.demo;

import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class AsyncService {
	repo rp = new repo();
	
	@Async
	public CompletableFuture<String> getdata(String str){
		return CompletableFuture.completedFuture(rp.getdata(str));
	}

}
