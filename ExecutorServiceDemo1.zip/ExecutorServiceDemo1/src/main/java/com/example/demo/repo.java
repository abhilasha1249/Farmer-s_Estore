package com.example.demo;

public class repo {

	public String getdata(String str) {
		try {
			System.out.println("processing query: "+str );
			Thread.sleep(10000);
			if(str.equals("query10")) {
				System.out.println(10/0);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Thread.currentThread().getName();
		
	}
}
